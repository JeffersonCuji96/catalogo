var spanishLanguageConfig = {
    "pagination": {
        "first": "Primero",
        "first_title": "Primera página",
        "last": "Último",
        "last_title": "Última página",
        "prev": "Anterior",
        "prev_title": "Página anterior",
        "next": "Siguiente",
        "next_title": "Página siguiente",
        "page_size": "Registros por página",
        "page_title": "Mostrar Página",
    }
};
